package Ex5;

/*public class Ex5 {
    public interface Livestock {

    }

    public abstract class Bird implements Livestock{
        Bird bird = new Chicken();
    }

    public class Chicken extends Bird {
        Bird bird = new Bird();
    }
}*/
