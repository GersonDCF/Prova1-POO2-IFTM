package Ex13;

public class ContaPoupanca extends Conta{
    private double taxaDeJuros;

    public ContaPoupanca(int numero, double saldo, double taxaDeJuros) {
        super(numero, saldo);
        this.taxaDeJuros = taxaDeJuros;
    }

    public double getTaxaDeJuros() {
        return taxaDeJuros;
    }

    public void setTaxaDeJuros(double taxaDeJuros) {
        this.taxaDeJuros = taxaDeJuros;
    }

    public double calcularRendimento() {
        return getSaldo() * getTaxaDeJuros();
    }
}

