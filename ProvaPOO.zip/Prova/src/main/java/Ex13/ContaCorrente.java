package Ex13;

public class ContaCorrente extends Conta{
    private double limiteChequeEspecial;

    public ContaCorrente(int numero, double saldo, double limite) {
        super(numero, saldo);
        this.limiteChequeEspecial = limite;
    }

    public double getLimiteChequeEspecial() {
        return limiteChequeEspecial;
    }

    public void setLimiteChequeEspecial(double limiteChequeEspecial) {
        this.limiteChequeEspecial = limiteChequeEspecial;
    }

    public void emitirExtrato() {
        System.out.println("Número da conta: " + getNumero());
        System.out.println("Saldo atual: " + getSaldo());
        System.out.println("Limite de crédito do cheque especial: " + getLimiteChequeEspecial());
    }
}