package Ex13;

public class Main {
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente(1, 700.00, 1000.00);
        ContaPoupanca cp = new ContaPoupanca(2, 500.00, 0.005);

        cc.sacar(200.00);
        cp.depositar(100.00);

        cc.emitirExtrato();
        System.out.println("Rendimento da conta poupança: " + cp.calcularRendimento());
    }
}
