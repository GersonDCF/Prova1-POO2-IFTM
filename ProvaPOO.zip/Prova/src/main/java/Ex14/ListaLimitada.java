package Ex14;

import java.util.ArrayList;
import java.util.List;

public class ListaLimitada<T> {
    private List<T> lista;
    private int tamanhoMaximo;

    public ListaLimitada(int tamanhoMaximo) {
        this.lista = new ArrayList<>();
        this.tamanhoMaximo = tamanhoMaximo;
    }

    public void adicionarElemento(T elemento) {
        if (lista.size() < tamanhoMaximo) {
            lista.add(elemento);
        } else {
            System.out.println("Não é possível adicionar mais elementos. A lista atingiu o tamanho máximo.");
        }
    }
}