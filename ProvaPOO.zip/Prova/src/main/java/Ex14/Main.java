package Ex14;

public class Main {
    public static void main(String[] args) {
        ListaLimitada<Integer> listaLimitada = new ListaLimitada<>(3);
        listaLimitada.adicionarElemento(1);
        listaLimitada.adicionarElemento(2);
        listaLimitada.adicionarElemento(3);
        listaLimitada.adicionarElemento(4);
    }
}