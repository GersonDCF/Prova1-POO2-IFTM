package Ex1;


public class Teste {
    public static void main(String[] args) {
        new B("C");
    }
}