package Ex1;


public class B extends A {
    public B (String s) {
        super();
        System.out.println("B");
    }
}