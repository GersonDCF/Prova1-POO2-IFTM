package Ex1;

public class A {
    public A (){
        System.out.print("A");
    }
}