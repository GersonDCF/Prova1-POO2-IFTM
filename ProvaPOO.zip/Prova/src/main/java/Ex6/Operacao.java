package Ex6;

public class Operacao {
    int a,b;

    public Operacao(int i, int j){
        a=i;
        b=j;
    }

    void calculo(Operacao o){
        System.out.print(o.a *= 1);
        System.out.print(" ");
        System.out.print(o.b /= 1);
    }
}
