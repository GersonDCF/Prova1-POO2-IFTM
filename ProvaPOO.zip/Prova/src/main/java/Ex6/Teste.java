package Ex6;

public class Teste {
    public static void main(String[] args) {
        Operacao op = new OperacaoN(10, 20, 5);
        op.calculo(op);
    }
}
