package Ex6;

public class OperacaoN extends Operacao{
    int n;

    public OperacaoN(int i, int j, int n){
        super(i,j);
        this.n = n;
    }

    @Override
    void calculo(Operacao o){
        System.out.print(o.a *= n);
        System.out.print(" ");
        System.out.print(o.b /= n);
    }
}
