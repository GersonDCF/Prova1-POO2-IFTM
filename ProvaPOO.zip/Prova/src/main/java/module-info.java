module com.example.aula05 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.aula05 to javafx.fxml;
    exports com.example.aula05;
}