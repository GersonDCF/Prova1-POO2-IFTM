package Ex3;

public class B extends A{
    int j;

    public void display(){
        System.out.print(j);
    }
}
