package Ex3;

public class A {
    int i;

    public void display(){
        System.out.print(i);
    }
}
