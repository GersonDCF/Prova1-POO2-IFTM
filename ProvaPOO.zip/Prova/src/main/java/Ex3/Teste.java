package Ex3;

public class Teste {
    public static void main(String[] args){
        B obj = new B();
        obj.i = 1;
        obj.j = 2;
        A r;
        r = obj;
        r.display();
    }
}
