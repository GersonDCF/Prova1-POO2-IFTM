package Ex10;

public class Derived {
    public void getDetails(String temp){
        System.out.println("Derived class " + temp);
    }
}
