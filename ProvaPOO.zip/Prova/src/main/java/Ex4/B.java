package Ex4;

public class B extends A{
    public void someMeth(String x){
        System.out.println("From class B "+ x);
    }
}
