package Ex4;

public class A {
    private void someMeth(){
        System.out.println("From class A");
    }
}
