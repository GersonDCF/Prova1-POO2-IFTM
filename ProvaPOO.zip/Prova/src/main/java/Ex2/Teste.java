package Ex2;

/*public class Teste {

    public int getData(){
        return 0;
    }

    public long getData(){
        return 1;
    }

    public static void main(String[] args) {
        Teste obj = new Teste();
        obj.getData();
    }
}*/