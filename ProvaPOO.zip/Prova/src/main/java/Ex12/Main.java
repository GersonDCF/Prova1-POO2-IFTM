package Ex12;

public class Main {
    public static void main(String[] args) {
        Retangulo retangulo = new Retangulo(20, 10);
        System.out.println("Área do retângulo: " + retangulo.calcularArea());

        Circulo circulo = new Circulo(10);
        System.out.println("Área do círculo: " + circulo.calcularArea());

        TrianguloEquilatero triangulo = new TrianguloEquilatero(10);
        System.out.println("Área do triângulo equilátero: " + triangulo.calcularArea());
    }
}