package Ex12;

public interface FormaGeometrica {
    public double calcularArea();
}
