package Ex11;

public abstract class Pagamento {
    private double valor;

    public abstract void processarPagamento();

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
