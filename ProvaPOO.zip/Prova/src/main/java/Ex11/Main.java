package Ex11;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        PagamentoBoleto boleto = new PagamentoBoleto(500.0, "12345678910");
        PagamentoCartao cartao = new PagamentoCartao(1000.0, "1234-1234-1234-1234");
        PagamentoPix pix = new PagamentoPix(3000.0, "123.456.789.10");

        GerenciarPagamentos gerenciador = new GerenciarPagamentos();
        gerenciador.exibirPagamentos(List.of(boleto, cartao, pix));
    }
}
