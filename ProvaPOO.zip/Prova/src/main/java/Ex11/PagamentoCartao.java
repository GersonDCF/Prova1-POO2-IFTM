package Ex11;

public class PagamentoCartao extends Pagamento {
    private String numeroCartao;

    public PagamentoCartao(double valor, String numeroCartao) {
            setValor(valor);
            this.numeroCartao = numeroCartao;
    }

    @Override
    public void processarPagamento() {
        System.out.println("Número do cartão: " + numeroCartao);
        System.out.println("Valor do pagamento: " + getValor());
    }
}
