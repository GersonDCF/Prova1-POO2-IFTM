package Ex11;

public class PagamentoPix extends Pagamento {
    private String chavePix;

    public PagamentoPix(double valor, String chavePix) {
        setValor(valor);
        this.chavePix = chavePix;
    }

    @Override
    public void processarPagamento() {
        System.out.println("Chave pix: " + chavePix);
        System.out.println("Valor do pagamento: " + getValor());
    }
}