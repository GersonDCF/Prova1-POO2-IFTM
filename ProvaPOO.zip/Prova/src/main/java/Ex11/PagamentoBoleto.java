package Ex11;

public class PagamentoBoleto extends Pagamento {
    private String codigoBarras;

    public PagamentoBoleto(double valor, String codigoBarras) {
        setValor(valor);
        this.codigoBarras = codigoBarras;
    }

    @Override
    public void processarPagamento() {
        System.out.println("Código de barras: " + codigoBarras);
        System.out.println("Valor do pagamento: " + getValor());
    }
}