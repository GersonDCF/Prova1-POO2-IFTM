package Ex11;

import java.util.List;

public class GerenciarPagamentos {
    public void exibirPagamentos(List<Pagamento> pagamentos) {
        for (Pagamento pagamento : pagamentos) {
            pagamento.processarPagamento();
            System.out.println();
        }
    }
}

