package Ex7;

public class Person {
    Person p = new Person();
}
