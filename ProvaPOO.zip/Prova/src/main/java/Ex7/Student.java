package Ex7;

public class Student extends Person{
    Student s = new Student();
}
