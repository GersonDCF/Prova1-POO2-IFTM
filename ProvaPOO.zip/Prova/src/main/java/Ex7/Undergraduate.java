package Ex7;

public class Undergraduate extends Student{
    Undergraduate ug = new Undergraduate();
}
