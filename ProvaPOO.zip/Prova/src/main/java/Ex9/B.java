package Ex9;

public class B extends A{
    int j;

    public void display(){
        System.out.println(j);
    }
}
