package Ex9;

public class Teste {
    public static void main(String[] args) {
        B a = new B();
        a.i = 1;
        a.j = 2;
        A b;
        b = a;
        b.display();
    }
}
