package Ex9;

public class A {
    int i;

    public void display(){
        System.out.println(i);
    }
}
