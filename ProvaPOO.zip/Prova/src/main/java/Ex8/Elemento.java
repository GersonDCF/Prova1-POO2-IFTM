package Ex8;

public class Elemento <T extends Number>{
    public void display(T e){
        System.out.print(e + " ");
    }
}
