package Ex8;

/*public class Teste {
    public static void main(String[] args){
        Elemento<Integer> e1 = new Elemento<>();
        Elemento<Float> e2 = new Elemento<>();
        Elemento<Double> e3 = new Elemento<>();
        Elemento<String> e4 = new Elemento<>();

        e1.display(1);
        e2.display(2.0f);
        e3.display(3.0);
        e4.display("quatro");
    }
}*/
